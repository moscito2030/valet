# Valet Viewer

Valet 與 Valet Review 共用的獨立橋牌牌局檢視器，套件名稱為 `@valet/deal-viewer`。

提供四家手牌、單家視角、合法試打、悔牌、花色加點數鍵盤操作、雙夢家分析、Par、LoTT 與共用牌桌樣式。已出牌保留原位並淡化、停用；隱藏手牌與首攻後亮夢家的規則不變。資料儲存、匯入匯出、跨桌算分與賽務由使用它的應用程式負責。

## 開發與驗證

需要 Node.js 22 以上。執行 `npm ci`、`npm test`、`npm run build`。
原始碼位於此倉庫根目錄。build 產生含 JavaScript、型別、樣式與 worker 的 dist；npm pack 僅封裝 dist 與說明文件，不包含其他專案或 node_modules。

## 使用

```tsx
import { DealExplorer, BoardInformation } from '@valet/deal-viewer';
import '@valet/deal-viewer/style.css';
```

React 19 與 lucide-react 為 peer dependencies。由外層提供 board、result、playerNames、牌號導航與分數；套件不連接資料庫。應用程式的 prepare-dds 腳本需將 `@valet/deal-viewer/dds-worker.js` 複製到 public/dds-worker.js，並準備 bridge-dds 引擎。Valet 與 Review 已接好此流程。

## 同步發布到兩個應用程式

1. 修改 Viewer 並提升 package.json 版本，執行 npm install --offline --ignore-scripts 更新鎖定檔。
2. 執行 npm test。
3. 執行 `npm run sync -- ../alternative_online_bridge ../valet-review`。
4. 此命令只打包一次，將同一個版本檔放進兩邊 vendor/ 並更新依賴與鎖定檔。
5. 兩個應用程式各自執行 npm test 與 npm run build，驗證瀏覽器操作，三個倉庫各自 commit。

不要覆寫已發布的相同版本；每次變更提升版本。兩個應用程式攜帶固定版本 tgz，因此 npm ci、建置與部署都不需要 Viewer 倉庫或私人 registry。回退時可還原依賴、鎖定檔與對應打包檔。推送由使用者控制。
